﻿using Microsoft.EntityFrameworkCore;
using Pract9Api.Models;

namespace Pract9Api.Data;

public class EntityApiContext : DbContext
{
    public EntityApiContext(DbContextOptions<EntityApiContext> options) : base(options) { }

    public DbSet<Product> Products => Set<Product>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<User> Users => Set<User>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<User>()
            .HasIndex(u => u.Login)
            .IsUnique();
    }
}