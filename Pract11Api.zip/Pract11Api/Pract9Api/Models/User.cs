﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pract9Api.Models;

[Table("users")]
public class User
{
    [Key]
    [Column("ID_user")]
    public int Id { get; set; }

    [Column("login")]
    [MaxLength(100)]
    public string Login { get; set; } = null!;

    [Column("password_hash")]
    public string PasswordHash { get; set; } = null!;

    [Column("role")]
    [MaxLength(50)]
    public string Role { get; set; } = null!;

    [Column("is_active")]
    public bool IsActive { get; set; } = true;
}