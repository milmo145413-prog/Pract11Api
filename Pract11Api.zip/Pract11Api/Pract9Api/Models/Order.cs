﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pract9Api.Models;

[Table("orders")]
public class Order
{
    [Key]
    [Column("ID_orders")]
    public int Id { get; set; }

    [Column("user_ID")]
    public int UserId { get; set; }

    [Column("order_number")]
    public string OrderNumber { get; set; } = null!;

    [Column("order_date")]
    public DateTime OrderDate { get; set; }

    [Column("total_amount")]
    public decimal TotalAmount { get; set; }

    [Column("shipping_address")]
    public string ShippingAddress { get; set; } = null!;

    [Column("contact_phone")]
    public string? ContactPhone { get; set; }

    [Column("payment_method")]
    public string? PaymentMethod { get; set; }
}