﻿namespace Pract9Api.Models;

public static class UserRoles
{
    public const string Admin = "Admin";
    public const string Manager = "Manager";
}