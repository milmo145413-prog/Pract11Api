﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pract9Api.Models;

[Table("products")]
public class Product
{
    [Key]
    [Column("ID_products")]
    public int Id { get; set; }

    [Column("title")]
    public string Title { get; set; } = null!;

    [Column("discription")]
    public string? Description { get; set; }

    [Column("price")]
    public decimal Price { get; set; }

    [Column("ID_category")]
    public int CategoryId { get; set; }

    [Column("stock_quantity")]
    public int StockQuantity { get; set; }

    [Column("created_at")]
    public DateTime CreatedAt { get; set; }
}