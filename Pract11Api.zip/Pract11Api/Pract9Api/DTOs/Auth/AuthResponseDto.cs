﻿namespace Pract9Api.DTOs.Auth;

public class AuthResponseDto
{
    public string AccessToken { get; set; } = null!;
    public int ExpiresInMinutes { get; set; }
    public string Role { get; set; } = null!;
}