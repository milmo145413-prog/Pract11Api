﻿using System.ComponentModel.DataAnnotations;

namespace Pract9Api.DTOs.Auth;

public class LoginDto
{
    [Required]
    public string Login { get; set; } = null!;

    [Required]
    public string Password { get; set; } = null!;
}