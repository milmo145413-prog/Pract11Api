﻿using System.ComponentModel.DataAnnotations;

namespace Pract9Api.DTOs.Auth;

public class RegisterDto
{
    [Required]
    [MinLength(3)]
    public string Login { get; set; } = null!;

    [Required]
    [MinLength(6)]
    public string Password { get; set; } = null!;
}