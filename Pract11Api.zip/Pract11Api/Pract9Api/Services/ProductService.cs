﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Pract9Api.Data;
using Pract9Api.DTOs;
using Pract9Api.Models;
using Pract9Api.Repositories;

namespace Pract9Api.Services;

public class ProductService : IProductService
{
    private readonly IProductRepository _repository;
    private readonly IMapper _mapper;
    private readonly EntityApiContext _context;

    public ProductService(IProductRepository repository, IMapper mapper, EntityApiContext context)
    {
        _repository = repository;
        _mapper = mapper;
        _context = context;
    }

    public async Task<(List<ProductDto> Items, int TotalCount)> GetAllAsync(int page, int pageSize, CancellationToken ct)
    {
        var items = await _repository.GetAllAsync(page, pageSize, ct);
        var total = await _repository.CountAsync(ct);
        return (_mapper.Map<List<ProductDto>>(items), total);
    }

    public async Task<ProductDto?> GetByIdAsync(int id, CancellationToken ct)
    {
        var product = await _repository.GetByIdAsync(id, ct);
        return product == null ? null : _mapper.Map<ProductDto>(product);
    }

    public async Task<ProductDto> CreateAsync(CreateProductDto dto, CancellationToken ct)
    {
        var product = _mapper.Map<Product>(dto);
        product.CreatedAt = DateTime.UtcNow;
        await _repository.AddAsync(product);
        await _repository.SaveChangesAsync();
        return _mapper.Map<ProductDto>(product);
    }

    public async Task<ProductDto?> UpdateAsync(int id, UpdateProductDto dto, CancellationToken ct)
    {
        var product = await _repository.GetByIdAsync(id, ct);
        if (product == null) return null;

        _mapper.Map(dto, product);
        _repository.Update(product);
        await _repository.SaveChangesAsync();
        return _mapper.Map<ProductDto>(product);
    }

    public async Task<ProductDto?> PatchAsync(int id, PatchProductDto dto, CancellationToken ct)
    {
        var product = await _repository.GetByIdAsync(id, ct);
        if (product == null) return null;

        _mapper.Map(dto, product);
        _repository.Update(product);
        await _repository.SaveChangesAsync();
        return _mapper.Map<ProductDto>(product);
    }

    public async Task<bool> DeleteAsync(int id, CancellationToken ct)
    {
        var product = await _repository.GetByIdAsync(id, ct);
        if (product == null) return false;

        _repository.Remove(product);
        await _repository.SaveChangesAsync();
        return true;
    }

    public async Task<OrderDto> ReserveProductAsync(int productId, int quantity, CancellationToken ct)
    {
        var product = await _context.Products.FirstOrDefaultAsync(p => p.Id == productId, ct);
        if (product == null) throw new InvalidOperationException($"Товар с Id {productId} не найден.");

        if (product.StockQuantity < quantity)
            throw new InvalidOperationException($"Недостаточно товара. В наличии: {product.StockQuantity}");

        product.StockQuantity -= quantity;

        var order = new Order
        {
            UserId = 1,
            OrderNumber = Guid.NewGuid().ToString().Substring(0, 8),
            OrderDate = DateTime.UtcNow,
            TotalAmount = product.Price * quantity,
            ShippingAddress = "Тестовый адрес",
            PaymentMethod = "Card"
        };

        _context.Orders.Add(order);
        await _context.SaveChangesAsync(ct);

        return _mapper.Map<OrderDto>(order);
    }

    public async Task<bool> CancelReservationAsync(int orderId, CancellationToken ct)
    {
        var order = await _context.Orders.FirstOrDefaultAsync(o => o.Id == orderId, ct);
        if (order == null) return false;

        var product = await _context.Products.FirstOrDefaultAsync(ct);
        if (product != null)
        {
            product.StockQuantity += 1;
        }

        _context.Orders.Remove(order);
        await _context.SaveChangesAsync(ct);
        return true;
    }
}