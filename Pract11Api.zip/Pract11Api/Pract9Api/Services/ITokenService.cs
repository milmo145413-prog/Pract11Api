﻿using Pract9Api.Models;

namespace Pract9Api.Services;

public interface ITokenService
{
    string CreateAccessToken(User user);
}