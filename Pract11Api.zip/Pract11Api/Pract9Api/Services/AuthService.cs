﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Pract9Api.Data;
using Pract9Api.Models;

namespace Pract9Api.Services;

public class AuthService : IAuthService
{
    private readonly EntityApiContext _context;
    private readonly PasswordHasher<User> _hasher = new();

    public AuthService(EntityApiContext context)
    {
        _context = context;
    }

    public async Task<User> RegisterAsync(string login, string password)
    {
        var exists = await _context.Users.AnyAsync(u => u.Login == login);
        if (exists)
            throw new InvalidOperationException($"Логин '{login}' уже занят.");

        var user = new User
        {
            Login = login,
            Role = UserRoles.Manager,   
            IsActive = true
        };
        user.PasswordHash = _hasher.HashPassword(user, password);

        _context.Users.Add(user);
        await _context.SaveChangesAsync();
        return user;
    }

    public async Task<User?> ValidateCredentialsAsync(string login, string password)
    {
        var user = await _context.Users
            .FirstOrDefaultAsync(u => u.Login == login && u.IsActive);

        if (user is null) return null;

        var result = _hasher.VerifyHashedPassword(user, user.PasswordHash, password);
        return result == PasswordVerificationResult.Failed ? null : user;
    }
}