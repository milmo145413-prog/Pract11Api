﻿using Pract9Api.Models;

namespace Pract9Api.Services;

public interface IAuthService
{
    Task<User> RegisterAsync(string login, string password);
    Task<User?> ValidateCredentialsAsync(string login, string password);
}