﻿using Microsoft.AspNetCore.Mvc;
using Pract9Api.DTOs.Auth;
using Pract9Api.Services;

namespace Pract9Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _authService;
    private readonly ITokenService _tokenService;
    private readonly IConfiguration _config;

    public AuthController(
        IAuthService authService,
        ITokenService tokenService,
        IConfiguration config)
    {
        _authService = authService;
        _tokenService = tokenService;
        _config = config;
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterDto dto)
    {
        try
        {
            var user = await _authService.RegisterAsync(dto.Login, dto.Password);
            var token = _tokenService.CreateAccessToken(user);
            return Ok(new AuthResponseDto
            {
                AccessToken = token,
                ExpiresInMinutes = int.Parse(_config["Jwt:AccessTokenMinutes"]!),
                Role = user.Role
            });
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginDto dto)
    {
        var user = await _authService.ValidateCredentialsAsync(dto.Login, dto.Password);
        if (user is null)
            return Unauthorized(new { error = "Неверный логин или пароль." });

        var token = _tokenService.CreateAccessToken(user);
        return Ok(new AuthResponseDto
        {
            AccessToken = token,
            ExpiresInMinutes = int.Parse(_config["Jwt:AccessTokenMinutes"]!),
            Role = user.Role
        });
    }
}