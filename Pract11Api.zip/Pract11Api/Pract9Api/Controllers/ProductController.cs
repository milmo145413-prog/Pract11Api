﻿using Microsoft.AspNetCore.Mvc;
using Pract9Api.DTOs;
using Pract9Api.Services;

namespace Pract9Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductController : ControllerBase
{
    private readonly IProductService _productService;

    public ProductController(IProductService productService)
    {
        _productService = productService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll(int page = 1, int pageSize = 10, CancellationToken ct = default)
    {
        var (items, total) = await _productService.GetAllAsync(page, pageSize, ct);
        Response.Headers.Append("X-Total-Count", total.ToString());
        return Ok(items);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
    {
        var item = await _productService.GetByIdAsync(id, ct);
        if (item == null) return NotFound();
        return Ok(item);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateProductDto dto, CancellationToken ct)
    {
        var item = await _productService.CreateAsync(dto, ct);
        return CreatedAtAction(nameof(GetById), new { id = item.Id }, item);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, UpdateProductDto dto, CancellationToken ct)
    {
        var item = await _productService.UpdateAsync(id, dto, ct);
        if (item == null) return NotFound();
        return Ok(item);
    }

    [HttpPatch("{id}")]
    public async Task<IActionResult> Patch(int id, PatchProductDto dto, CancellationToken ct)
    {
        var item = await _productService.PatchAsync(id, dto, ct);
        if (item == null) return NotFound();
        return Ok(item);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        var deleted = await _productService.DeleteAsync(id, ct);
        if (!deleted) return NotFound();
        return NoContent();
    }

    [HttpPost("{id}/reserve")]
    public async Task<IActionResult> Reserve(int id, [FromQuery] int quantity, CancellationToken ct)
    {
        try
        {
            var order = await _productService.ReserveProductAsync(id, quantity, ct);
            return Ok(order);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }

    [HttpPost("cancel/{orderId}")]
    public async Task<IActionResult> Cancel(int orderId, CancellationToken ct)
    {
        var result = await _productService.CancelReservationAsync(orderId, ct);
        if (!result) return NotFound();
        return NoContent();
    }
}